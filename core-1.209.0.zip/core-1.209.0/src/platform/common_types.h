#pragma once

typedef unsigned short CHAR16;
